function [p_reflection] = MReflection2D(mgrid, medium, p_ref, ...
                          M_linear, K, K2, cw, sensor_mask, ...
                          reflection_order, GPU, sing)
% DESCRIPTION:
% Simpson-like integration for the reflection projection with transmission 
% corrections

% USAGE:
% [p_reflection] = MReflection2D(mgrid, medium, p_ref, M_linear,...
%                   K, K2, cw, sensor_mask, reflection_order, GPU, sing)

% INPUTS:
% mgrid             structure to define the computational domain
% medium            medium properties
% p_ref             stored reflected part
% M_linear          linear part of the M term on RHS of solution equation 
%                   obtained with function Mterm2D_MMDM   
% K                 wave number along the y direction with constant c
% K2                wave number along the y direction with heterogeneous c
% cw                frequency-dependent speed of sound
% sensor_mask       a set of Cartesian points where the pressure is recorded
% reflection_order  the maximum order of reflection included in the simulation
% GPU               flag for running on gpu
% sing              flag for running in single precision

% OUTPUTS:
% p_reflection      reflection                       
     
%%
% exponential term for the forward propagation
expn2 = exp(0.5*1i*K*mgrid.dy); 

% dump key values to GPU and/or set single precision
    if sing~=0
        expn2=single(expn2);
    end
    if GPU~=0
        expn2=gpuArray(expn2);
    end

% 1.05 is an empirical number, it can be higher if necessay
evanescent_fiter = 1.05;

% preallocate space for the reflections
p_reflection = zeros(mgrid.num_t, sum(sum(sensor_mask)));

rho_rho = medium.rho;
if length(medium.rho) == 1
    rho_rho = medium.rho*ones(mgrid.num_x, mgrid.num_y+1);
end  

jtj=0.5*mgrid.dy.*expn2./(2i.*K);
    
mw2=(mgrid.w'*ones(1,mgrid.num_x)).^2;
efil2=evanescent_fiter*ones(mgrid.num_t,1)*mgrid.kx.^2;

wx2 = (mgrid.w.*mgrid.w).'*ones(1,mgrid.num_x);
k_dif0=wx2*mgrid.dy./medium.c0./medium.c0;
clear wx2

% waitbar
h = waitbar(0,'Reflection projection, please wait...');

% Simpson iteration
for iref = 1:reflection_order
    
    if mod(iref,2)==1
        
        % initial an array to store reflected parts
        p_ref2 = zeros(mgrid.num_t,mgrid.num_x,mgrid.num_y+1); 
        f = zeros(size(p_ref(:,:,1)));
        if sing~=0
            f=single(f);
        end
        if GPU~=0
            f=gpuArray(f);
        end
        
        for I = mgrid.num_y:-1:1 % the layer at which the main waveform arrives
            
            % low pass filter
            Ktemp1 = real(mw2./cw(:,:,I)./cw(:,:,I) - efil2); 
            
            M_lin2=M_linear(:,:,I);
            M_lin3=M_linear(:,:,I+1);
            
            % dump key values to GPU and/or set single precision
            if sing~=0
                M_lin2=single(M_lin2);
                M_lin3=single(M_lin3);
            end
            if GPU~=0
                M_lin2=gpuArray(M_lin2);
                M_lin3=gpuArray(M_lin3);
            end
            
            % reflection for propagation
            f = f + p_ref(:,:,I+1);  
            excit_F = fftshift(fft2(f));

            % Simpson   
            % 1    
            Ft  = fftshift(fft(f,[],1),1);
            M = fftshift(fft((M_lin3).*Ft,[],2),2);     % M(f(z))
            clear Ft   f
            F1 = excit_F.*expn2 + jtj.*M;  % P01(z-mgrid.dy/2)
            F1(isnan(F1)) = 0;
            F1(Ktemp1<=0) = 0; 

            % 2
            f   = real(ifft2(ifftshift(F1)));  % p0(z-mgrid.dy/2)
            clear F1
            Ft  = fftshift(fft(f,[],1),1);     % fft(f) 
            M1 = fftshift(fft((M_lin3).*Ft,[],2),2);  % M(f(z))
            clear f
            F2 = excit_F.*expn2 + 0.5*jtj.*(M + M1./expn2);% P12(z-mgrid.dy/2)
            F2(isnan(F2)) = 0;
            F2(Ktemp1<=0) = 0; 
            clear M1
    
            % 3   
            f   = real(ifft2(ifftshift(F2))); % p1(z-mgrid.dy/2) 
            Ft  = fftshift(fft(f,[],1),1);    % fft(f1) 
            M2  = fftshift(fft((M_lin3).*Ft,[],2),2);  % M(f1(z-mgrid.dy/2))
            F3 = F2.*expn2 + jtj.*M2;  % P03(z-mgrid.dy)
            F3(isnan(F3)) = 0;
            F3(Ktemp1<=0) = 0; 
    
            % 4     
            f   = real(ifft2(ifftshift(F3))); % p0(z-mgrid.dy)  
            clear F3
            Ft  = fftshift(fft(f,[],1),1);    % fft(f2) 
            M3  = fftshift(fft((M_lin2).*Ft,[],2),2);  % M(f1(z-mgrid.dy))
            F4 = F2.*expn2 + 0.5*jtj.*(M2 + M3./expn2); % P14(z-mgrid.dy)
            F4(isnan(F4)) = 0;
            F4(Ktemp1<=0) = 0;   
            clear M3
      
            % 5   
            f   = real(ifft2(ifftshift(F4))); % p0(z-mgrid.dy)  
            clear F4
            Ft  = fftshift(fft(f,[],1),1);    % fft(f2) 
            M4  = fftshift(fft((M_lin2).*Ft,[],2),2); % M(f1(z-mgrid.dy))
            F5 = excit_F.*expn2.*expn2 + jtj/3.0.*...
                 (M.*expn2 + 4*M2 + M4./expn2); % P25(z-mgrid.dy)
            F5(isnan(F5)) = 0;
            F5(Ktemp1<=0) = 0; 
            clear M M2 M4
             
            %% add phase correction        
            c3 = cw(:,:,I+1);
            c2 = cw(:,:,I);    
            rho2 = (repmat(rho_rho(:,I)', mgrid.num_t,1));
            rho3 = (repmat(rho_rho(:,I+1)', mgrid.num_t,1));
       %    rho2 = ones(mgrid.num_t,1)*rho_rho(:,I).' ;    
       %    rho3 = ones(mgrid.num_t,1)*rho_rho(:,I+1).'; 
            
       %    wx2 = (mgrid.w.*mgrid.w).'*ones(1,mgrid.num_x);
            e12 = exp(1i*K2(:,:,I)*mgrid.dy);
       %    k_dif0=(wx2./medium.c0./medium.c0)*mgrid.dy;
            
            k_dif2 = k_dif0.*(1 - medium.c0.*medium.c0./c2./c2);      
            k_dif3  = k_dif0.*(1 - medium.c0.*medium.c0./c3./c3);
       %    clear  wx2  
            correction = excit_F.*e12.*(1-expn2.*expn2./e12.*...
                     (4i.*K+k_dif3)./(4i.*K-k_dif2));
            F5 = F5 + correction;  
            clear correction k_dif2  k_dif3  el2
            F5(isnan(F5)) = 0;
            F5(Ktemp1<=0) = 0;     
            %% amplitude correction    
            f = real(ifft2(ifftshift(F5)));
            T_rhoc = 2.*rho2.*c2./(rho3.*c3 + rho2.*c2); 
            f = f.*T_rhoc;
            clear rho3 c3 rho2 c2
    
            if sum(sum(sensor_mask(:,I)))~=0
                % calculate the starting position of recorded signal
                sensor_mask_I1 = sum(sum(sensor_mask(:,1:I-1)))+1;
       
                % calculate the ending position of recorded signal
                sensor_mask_I2 = sensor_mask_I1 -1 + ...
                sum(sum(sensor_mask(:,I)));
    
                % save the time-domain signals
                p_reflection(:,sensor_mask_I1:sensor_mask_I2) = ...
                   gather(p_reflection(:,sensor_mask_I1:sensor_mask_I2) +...
                   f(:,sensor_mask(:,I)~=0));
            
            end            
            % store the reflected part
            p_ref2(:,:,I+1) = gather(real(ifft2(ifftshift(excit_F))).*(T_rhoc-1));          
            clear T_rhoc    
            
            if mod(I,round(mgrid.num_y/25))==1
                waitbar(I/mgrid.num_y)
            end
        end
        
    else
        % initial an array to store the reflected part
        p_ref = zeros(size(p_ref));
        f = 0;
        for I = 2:mgrid.num_y+1 % the layer at which the main waveform arrives

            % low pass filter
            Ktemp1 = real(mw2./cw(:,:,I)./cw(:,:,I) - efil2); 
            
            M_lin2=M_linear(:,:,I);
            M_lin1=M_linear(:,:,I-1);
            
            % dump key values to GPU and/or set single precision
            if sing~=0
                M_lin2=single(M_lin2);
                M_lin1=single(M_lin1);
                Ktemp1=single(Ktemp1);
            end
            if GPU~=0
                M_lin2=gpuArray(M_lin2);
                M_lin1=gpuArray(M_lin1);
                Ktemp1=gpuArray(Ktemp1);
            end   
     
            f = f + squeeze(p_ref2(:,:,I-1));     
            excit_F = fftshift(fft2(f));
            
            % Simpson   
            % 1    
            Ft  = fftshift(fft(f,[],1),1);
            M = fftshift(fft((M_lin1).*Ft,[],2),2);           % M(f(z))
            F1 = excit_F.*expn2 + jtj.*M;  % P01(z-mgrid.dy/2)
            F1(isnan(F1)) = 0;
            F1(Ktemp1<=0) = 0; 

            % 2
            f   = real(ifft2(ifftshift(F1)));  % p0(z-mgrid.dy/2)
            Ft  = fftshift(fft(f,[],1),1);     % fft(f) 
            M1 = fftshift(fft((M_lin1).*Ft,[],2),2); % M(f(z))
            F2 = excit_F.*expn2 + 0.5*jtj.*(M + M1./expn2);% P12(z-mgrid.dy/2)
            F2(isnan(F2)) = 0;
            F2(Ktemp1<=0) = 0; 
    
            % 3   
            f   = real(ifft2(ifftshift(F2))); % p1(z-mgrid.dy/2)  
            Ft  = fftshift(fft(f,[],1),1);    % fft(f1) 
            M2  = fftshift(fft((M_lin1).*Ft,[],2),2);     % M(f1(z-mgrid.dy/2))
            F3 = F2.*expn2 + jtj.*M2;  % P03(z-mgrid.dy)
            F3(isnan(F3)) = 0;
            F3(Ktemp1<=0) = 0; 
    
            % 4     
            f   = real(ifft2(ifftshift(F3))); % p0(z-mgrid.dy)  
            Ft  = fftshift(fft(f,[],1),1);    % fft(f2) 
            M3  = fftshift(fft((M_lin2).*Ft,[],2),2);  % M(f1(z-mgrid.dy))
%             F2t = fftshift(fft(f.*f,[],1),1);
%             M3 = M3 + fftshift(fft(M_nonlinear(:,:,I).*F2t,[],2),2); 
            F4 = F2.*expn2 + 0.5*jtj.*(M2 + M3./expn2); % P14(z-mgrid.dy)
            F4(isnan(F4)) = 0;
            F4(Ktemp1<=0) = 0;    
    
            % 5   
            f   = real(ifft2(ifftshift(F4))); % p0(z-mgrid.dy)  
            Ft  = fftshift(fft(f,[],1),1);    % fft(f2) 
            M4  = fftshift(fft((M_lin2).*Ft,[],2),2); % M(f1(z-mgrid.dy))
            F5 = excit_F.*expn2.*expn2 +...
                 jtj/3.0.*(M.*expn2 + 4*M2 + M4./expn2); % P25(z-mgrid.dy)
            F5(isnan(F5)) = 0;
            F5(Ktemp1<=0) = 0; 
      
           %% phase    
           c1=cw(:,:,I-1);
           c2=cw(:,:,I);
           
            k_dif  = k_dif0.*(1 - medium.c0.*medium.c0./c1./c1); 
            k_dif2 = k_dif0.*(1 - medium.c0.*medium.c0./c2./c2); 
            e12  = exp(1i*(K2(:,:,I))*mgrid.dy);
            correction = excit_F.*e12.*(1-expn2.*expn2./e12.*...
                     (4i.*K+k_dif)./(4i.*K-k_dif2));

            F5 = F5 + correction;  
            clear correction k_dif2  k_dif  el2
            F5(isnan(F5)) = 0;
            F5(Ktemp1<=0) = 0; 
           
            %% amplitude correction    
            f = real(ifft2(ifftshift(F5)));
            rho1 = repmat(rho_rho(:,I-1)', mgrid.num_t,1); 
            rho2 = repmat(rho_rho(:,I)', mgrid.num_t,1);    
            
            T_rhoc = 2.*rho2.* c2./...
                    (rho1.*c1 + rho2.* c2); 
            f = f.*T_rhoc;
            clear rho1  rho2 c2 c1
            if sum(sum(sensor_mask(:,I)))~=0
                % calculate the starting position of recorded signal
                sensor_mask_I1 = sum(sum(sensor_mask(:,1:I-1)))+1;
       
                % calculate the ending position of recorded signal
                sensor_mask_I2 = sensor_mask_I1 -1 + ...
                sum(sum(sensor_mask(:,I)));
    
                % save the time-domain signals
                p_reflection(:,sensor_mask_I1:sensor_mask_I2) = ...
                    gather(p_reflection(:,sensor_mask_I1:sensor_mask_I2) +...
                    f(:,sensor_mask(:,I)~=0));
            end           
           
            % store the reflected parts
            p_ref(:,:,I-1) = gather(real(ifft2(ifftshift(excit_F))).*(T_rhoc-1)); 
           
            if mod(I,round(mgrid.num_y/25))==1
                waitbar(I-1/mgrid.num_y)
            end
        end        
         
    end
    
end
% close the waitbar
close(h) 

end


